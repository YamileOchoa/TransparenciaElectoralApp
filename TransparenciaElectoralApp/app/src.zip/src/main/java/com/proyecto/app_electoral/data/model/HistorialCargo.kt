package com.proyecto.app_electoral.data.model

data class HistorialCargo(
    val cargo: String,
    val institucion: String,
    val fecha_inicio: String,
    val fecha_fin: String,
    val descripcion: String
)
