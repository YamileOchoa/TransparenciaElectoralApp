package com.proyecto.app_electoral.data.db

// No se usa Room en este proyecto, ya que los datos provienen de un archivo JSON.