package com.proyecto.app_electoral.data.model

data class Propuesta(
    val titulo: String,
    val descripcion: String,
    val categoria: String,
    val prioridad: String
)
