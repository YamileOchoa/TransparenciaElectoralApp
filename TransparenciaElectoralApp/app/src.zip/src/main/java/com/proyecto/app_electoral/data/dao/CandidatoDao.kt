package com.proyecto.app_electoral.data.dao

import androidx.room.Dao

@Dao
interface CandidatoDao {

}
